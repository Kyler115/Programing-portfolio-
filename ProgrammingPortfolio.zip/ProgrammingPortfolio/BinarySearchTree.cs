﻿    using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    internal class BinarySearchTree
    {
        private BNode? root;
        public BinarySearchTree()
        {
            BNode root = new BNode(null);
        }
        public void Add(int val)
        {
            if (root == null)
            {
                root = new BNode(val);
                return;
            }
            BTreeAdd(root, val);
        }
        public int? Remove(int val) 
        {
            if (root == null) 
            {
                throw new NullReferenceException();
            }
            BTreeRemove(root, val);
            return val;
        }
        private int? BTreeRemove(BNode curr, int val)
        {
            if (curr == null)
                return null;

            if (curr.GetData() < val)
            {
                BTreeRemove(curr.GetRChild(),val);
                return val;
            }
            else if(curr.GetData() > val )
            {
                BTreeRemove(curr.GetLChild(), val);
                return val;
            }
            
            if (curr.GetLChild() == null && curr.GetRChild() == null)
            {

                if (curr.GetParent().GetRChild().GetData() == curr.GetData())
                {
                    curr.GetParent().SetRChild(null);
                    curr = null;
                }
                else
                {
                    curr.GetParent().SetLChild(null);
                    curr = null;
                    return val;
                }
                return val;
            }

        if (curr.GetParent().GetRChild().GetData() == curr.GetData())// if current is right child
            {
                if (curr.GetRChild().GetData() > curr.GetParent().GetData())// if current's right child  is greater than parent
                {
                    curr.GetParent().SetRChild(curr.GetRChild());//sets right child of curr parent to curr right child
                    curr = null;
                }
                else if (curr.GetLChild().GetData() > curr.GetParent().GetData())
                {
                    curr.GetParent().SetRChild(curr.GetLChild());
                    curr = null;
                }
            }
            return val;
        }
        private void BTreeAdd(BNode curr, int val)
        {
            if (curr == null)
                return;
            if (val < curr.GetData())
            {
                if (curr.GetLChild() != null)
                {
                    BTreeAdd(curr.GetLChild(), val);
                }
                else
                {
                    BNode node = new BNode(val);
                    curr.SetLChild(node);
                    node.SetParent(curr);
                }
            }
            else
            {
                if (curr.GetRChild() != null)
                {
                    BTreeAdd(curr.GetRChild(), val);
                }
                else
                {
                    BNode node = new BNode(val);
                    curr.SetRChild(node);
                    node.SetParent(curr);
                }
            }
            
        }
        public int Height(BNode curr)
        {
            int i = 0;
            while (curr.GetParent() != null)
            {
               i++;
               curr = curr.GetParent();
            }
            return i;
        }
        public void ToStringTree()
        {
            if (root == null)
                throw new NullReferenceException();
            TSRecursion(root);
        }

        public void TSRecursion(BNode current)
        {
            if (current == null)
                return;

            TSRecursion(current.GetRChild());
            for (int i = 0; i < Height(current); i++)
            {
                Console.Write("\t");
            }
            Console.Write(current.GetData()+"\n");
            TSRecursion(current.GetLChild());
        }

        public bool Has(int val)
        {
            BNode current = root;
            while (current != null)
            {
                if (current.GetData() > val)
                    current = current.GetLChild();
                else if (current.GetData() < val)
                    current = current.GetRChild();
                else if (current.GetData() == val)
                    return true;
            }    
            return false;
        }

    }
}
