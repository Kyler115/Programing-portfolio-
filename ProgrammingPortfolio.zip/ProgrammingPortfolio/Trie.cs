﻿using System.Xml.Linq;
using System;

namespace ProgrammingPortfolio
{
    internal class Trie
    {
        TNode? root;
        public Trie()
        {
            root = new TNode();
        }

        public void Add(string pass)
        {
            TAdd(pass, root, 0);
            //method mapping and exception if outside
        }

        private void TAdd(string item, TNode current, int stringIndex)
        {
            foreach (char c in item)
            {
                if (current.child[Search(c)] == null)
                {

                    current = current.child[Map(c, current)];
                                        
                }
                else if (current.child[Search(c)].data.Equals(c))                
                    current = current.child[Search(c)];
                else
                    current = current.child[Map(c, current)];
            }
           current.isEndOfWord = true;
        }
        private int Map(char c, TNode node)
        {
            TNode node1 = new TNode();
            switch (c) 
            {
                case 'a':
                    node1.SetData(c);
                    node.child[0] = node1;
                    return 0;
                case 'b':
                    node1.SetData(c);
                    node.child[1] = node1;
                    return 1;
                case 'c':
                    node1.SetData(c);
                    node.child[2] = node1;
                    return 2;
                case 'd':
                    node1.SetData(c);
                    node.child[3] = node1;
                    return 3;
                case 'e':
                    node1.SetData(c);
                    node.child[4] = node1;
                    return 4;
                case 'f':
                    node1.SetData(c);
                    node.child[5] = node1;
                    return 5;
                case 'g':
                    node1.SetData(c);
                    node.child[6] = node1;
                    return 6;
                case 'h':
                    node1.SetData(c);
                    node.child[7] = node1;
                    return 7;
                case 'i':
                    node1.SetData(c);
                    node.child[8] = node1;
                    return 8;
                case 'j':
                    node1.SetData(c);
                    node.child[9] = node1;
                    return 9;
                case 'k':
                    node1.SetData(c);
                    node.child[10] = node1;
                    return 10;
                case 'l':
                    node1.SetData(c);
                    node.child[11] = node1;
                    return 11;
                case 'm':
                    node1.SetData(c);
                    node.child[12] = node1;
                    return 12;
                case 'n':
                    node1.SetData(c);
                    node.child[13] = node1;
                    return 13;
                case 'o':
                    node1.SetData(c);
                    node.child[14] = node1;
                    return 14;
                case 'p':
                    node1.SetData(c);
                    node.child[15] = node1;
                    return 15;
                case 'q':
                    node1.SetData(c);
                    node.child[16] = node1;
                    return 16;
                case 'r':
                    node1.SetData(c);
                    node.child[17] = node1;
                    return 17;
                case 's':
                    node1.SetData(c);
                    node.child[18] = node1;
                    return 18;
                case 't':
                    node1.SetData(c);
                    node.child[19] = node1;
                    return 19;
                case 'u':
                    node1.SetData(c);
                    node.child[20] = node1;
                    return 20;
                case 'v':
                    node1.SetData(c);
                    node.child[21] = node1;
                    return 21;
                case 'w':
                    node1.SetData(c);
                    node.child[22] = node1;
                    return 22;
                case 'x':
                    node1.SetData(c);
                    node.child[23] = node1;
                    return 23;
                case 'y':
                    node1.SetData(c);
                    node.child[24] = node1;
                    return 24;
                case 'z':
                    node1.SetData(c);
                    node.child[25] = node1;
                    return 25;
                case '0':
                    node1.SetData(c);
                    node.child[26] = node1;
                    return 26;
                case '1':
                    node1.SetData(c);
                    node.child[27] = node1;
                    return 27;
                case '2':
                    node1.SetData(c);
                    node.child[28] = node1;
                    return 28;
                case '3':
                    node1.SetData(c);
                    node.child[29] = node1;
                    return 29;
                case '4':
                    node1.SetData(c);
                    node.child[30] = node1;
                    return 30;
                case '5':
                    node1.SetData(c);
                    node.child[31] = node1;
                    return 31;
                case '6':
                    node1.SetData(c);
                    node.child[32] = node1;
                    return 32;
                case '7':
                    node1.SetData(c);
                    node.child[33] = node1;
                    return 33;
                case '8':
                    node1.SetData(c);
                    node.child[34] = node1;
                    return 34;
                case '9':
                    node1.SetData(c);
                    node.child[35] = node1;
                    return 35;
                case '!':
                    node1.SetData(c);
                    node.child[36] = node1;
                    return 36;
                case ' ':
                    node1.SetData(c);
                    node.child[37] = node1;
                    return 37;
                case '@':
                    node1.SetData(c);
                    node.child[38] = node1;
                    return 38;
                case '.':
                    node1.SetData(c);
                    node.child[39] = node1;
                    return 39;
                case ':':
                    node1.SetData(c);
                    node.child[40] = node1;
                    return 40;
                case '~':
                    node1.SetData(c);
                    node.child[41] = node1;
                    return 41;
                case '?':
                    node1.SetData(c);
                    node.child[42] = node1;
                    return 42;
                case '$':
                    node1.SetData(c);
                    node.child[43] = node1;
                    return 43;
                case 'U':
                    node1.SetData(c);
                    node.child[44] = node1;
                    return 44;
                case 'п':
                    node1.SetData(c);
                    node.child[45] = node1;
                    return 45;
                case 'ї':
                    node1.SetData(c);
                    node.child[46] = node1;
                    return 46;
                case 'Ѕ':
                    node1.SetData(c);
                    node.child[47] = node1;
                    return 47;
                case 'E':
                    node1.SetData(c);
                    node.child[48] = node1;
                    return 48;
                default:
                    throw new Exception("exception, not found");
                    return -1;
            }

        }
        private int Search(char c)
        {
            switch (c)
            {
                case 'a':
                    return 0;
                case 'b':
                    return 1;
                case 'c':
                    return 2;
                case 'd':
                    return 3;
                case 'e':
                    return 4;
                case 'f':
                    return 5;
                case 'g':
                    return 6;
                case 'h':
                    return 7;
                case 'i':
                    return 8;
                case 'j':
                    return 9;
                case 'k':
                    return 10;
                case 'l':
                    return 11;
                case 'm':
                    return 12;
                case 'n':
                    return 13;
                case 'o':
                    return 14;
                case 'p':
                    return 15;
                case 'q':
                    return 16;
                case 'r':
                    return 17;
                case 's':
                    return 18;
                case 't':
                    return 19;
                case 'u':
                    return 20;
                case 'v':
                    return 21;
                case 'w':
                    return 22;
                case 'x':
                    return 23;
                case 'y':
                    return 24;
                case 'z':
                    return 25;
                case '0':
                    return 26;
                case '1':
                    return 27;
                case '2':
                    return 28;
                case '3':
                    return 29;
                case '4':
                    return 30;
                case '5':
                    return 31;
                case '6':
                    return 32;
                case '7':
                    return 33;
                case '8':
                    return 34;
                case '9':
                    return 35;
                case '!':
                    return 36;
                case ' ':
                    return 37;
                case '@':
                    return 38;
                case '.':
                    return 39;
                case ':':
                    return 40;
                case '~':
                    return 41;
                case '?':
                    return 42;
                case '$':
                    return 43;
                case 'U':
                    return 44;
                case 'п':
                    return 45;
                case 'ї':
                    return 46;
                case 'Ѕ':
                    return 47;
                case 'E':
                    return 48;
                default:
                    return -1;
            }
        }

        public bool has(String item)
        {
            TNode node = root;
            foreach (char c in item)
            {
                if (node.child[Search(c)]!=null)
                { 
                int index = Search(c);
                node = node.child[index]; 
                }
            }
            if (node.isEndOfWord == true)
                return true;
            else
                return false;
        }

        public string Remove(string pass)
        {
            TNode node = new TNode();
            node = root;
            foreach (char c in pass)
            {
                if (node.child[Search(c)] == null)
                    return "word is not in trie";
                node = node.child[Search(c)];
            }
            if (node.isEndOfWord == true)
            {
                int i = Search(pass[pass.Length-1]);
                while (i != -1)
                {
                    node.data = null;
                    i--;
                }
                return pass+" is in trie, and has been removed.";
            }
            else
                return pass+" is not in trie";
        }
    }
}