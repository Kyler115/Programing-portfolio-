﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ProgrammingPortfolio
{
    public class LinkedList<LType>
    {
        internal class LListNode<T> : LNode<T>
        {
            public LListNode<T>? next;
            public LListNode(T val, LListNode<T>? next = null) : base(val)
            {
                this.next = next;
            }
        }
        private LListNode<LType>? head;
        private int numItems;
        public int Size()
        {
            return numItems;
        }

        public LinkedList()
        {
            head = null;
            numItems = 0;
        }

        public LinkedList(LType val)
        {
            head = new LListNode<LType>(val);
            numItems = 1;
        }
        public LType Get(int position)
        {
            if (position > numItems)
            {
                throw new IndexOutOfRangeException();
            }
            var node = head;
            for (int i = 0; i < position; i++)
            {
                node = node.next;
            }
            if (node == null)
            {
                throw new ArgumentException("Null Node found");
            }
            return node.Data;
        }
        public LType this[int i]
        {
            get => Get(i);
            set => AddAt(value, i);
        }

        public void AddAt(LType item, int pos)
        {
            if (pos == 0)
            {
                AddHead(item);
                return;
            }
            else if (pos > numItems)
            {
                throw new IndexOutOfRangeException();
            }
            var node1 = head;
            for (int i = 0; i < pos - 1; i++)
            {
                node1 = node1.next;
            }
            var nextnode = node1.next;
            var newNode = new LListNode<LType>(item, next: nextnode);
            node1.next = newNode;
            numItems++;
        }
        public void AddHead(LType val)
        {
            var newNode = new LListNode<LType>(val, next: head);
            if (newNode.next != null)
            {
                //.prev
                newNode.next = head;
            }
            numItems++;
            head = newNode;
        }

        public LType RemoveAt(int pos) 
        { 
            if(pos>numItems)
                throw new ArgumentException ();
            if (head == null)
                throw new ArgumentException();
            var node = head;
            for (int i = 0; i < pos-1; i++)
            {
                if (node.next != null)
                {
                    node = node.next;
                }
            }
            LType temp = node.next.Data;
            node.next = node.next.next;
            numItems--;
            
            return temp;

        }

    }
}

