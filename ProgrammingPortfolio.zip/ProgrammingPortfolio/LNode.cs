﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    public class LNode<NodeType>
    {
        private NodeType data;
        private LNode<NodeType> next;
        //diff ?
        public LNode(NodeType val)
        {
            data = val;
        }
        public NodeType Data
        {
            get { return data; }
            set { data = value; }            
        }

        public NodeType getData() { return data; }
        public LNode<NodeType> getNext() { return next; }
        public void setNext(LNode<NodeType> next) { this.next = next; }
        public void setData(NodeType t) { this.data = t; }
    }
}
