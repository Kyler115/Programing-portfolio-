﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    internal class SlowSort
    {
        public void Sort(int[] list)
        {
            for (int i = 0; i < list.Length - i; i++)
            {
                for (int j = 0; j < list.Length - 1; j++)//j was set = to i. that was the issue.
                {
                    if (list[j] > list[j+1])
                    {
                        int temp = list[j+1];
                        list[j+1] = list[j];
                        list[j] = temp;
                    }
                }                
            }
        }
    }
}
