﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    internal class Stack<LType>
    {
        private int size = 0;
        private DynamicArray<LType> stack = new DynamicArray<LType>();
        public Stack()
        {
            DynamicArray<LType> stack = new DynamicArray<LType>();
        }
        public void Push(LType item)
        {
            stack.Add(item, 0);
            size = size + 1;
        }
        public LType Pop()
        {
            if (size == 0)
                throw new IndexOutOfRangeException("Size is 0");
            LType value = stack.Remove(0);
            size = size-1;
            return value;
        }
        public LType Peek()
        {
            return stack.Get(0);
        }

        public int Size()
        {
            return size;
        }
    }
}
