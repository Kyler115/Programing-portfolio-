﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    public class MaxHeap
    {
        DynamicArray<int> heap;
        int length;
        public MaxHeap() 
        {
            heap = new DynamicArray<int>();
            length = 0;
        }
        public void Add(int value) 
        {
            if (heap.Get(0) == null)
            {
                heap.Add(value, 0);
            }
            else
                MAdd(0, value);
        }

        public void MAdd(int root, int value)
        {
            if (heap.Get(root) <= value)
            {
                while (heap.Get(root) <= value || heap.Get(root) != null)
                {
                    int? temp = heap.Get(root);//possible nullable issue
                    //heap.Remove(root);
                    heap.Set(value, root);
                    heap.Add((int)temp, root+1);
                    root--;
                    if (root == -1)
                        break;
                }
                length++;
            }
            else if (heap.Get(root) >= value)
            { 
                while(heap.Get(root) >= value)
                {
                    root = root+1;
                    if (root >= heap.Size())
                        break;
                }
                heap.Add(value, root);
            }
        }
        public int Remove(int value) 
        {
            int search=0;
            while (heap.Size() > search)
            {
                if (heap.Get(search) == value)
                {
                    return heap.Remove(search);//was value
                    break;
                }
                search++;
            }
            return -1;
        }

        public int PrioRemove(int val)
        {
            return heap.Remove((int)val);
        }

        public int Get(int val)
        {
            return heap.Get(val);
        }

        public void Set(int val, int value)
        {
            heap.Set(value, val); 
        }
        
    }
}
