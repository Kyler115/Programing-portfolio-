﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    internal class QuickSort
    {
        int left = 0;
        int right;

        public void quickSort(int[] list)
        {
            Sort(list, 0, list.Length - 1);
        }

        public void Sort(int[] list, int left, int right)
        {
            if (left >= right)
                return;
            int pivot = list[right];
            int i = left;
            int j = right;
            while (i < j)
            {
                while (list[i] <= pivot && i < j)
                {
                    i++;
                }
                while (list[j] >= pivot && i < j)
                {
                    j--;
                }
                Swap(list, i, j);
            }
            Swap(list, i, right);
            Sort(list, left, i-1 );
            Sort(list,i+1, right);
        }

        public void Swap(int[] list, int i, int j)
        {
            int temp = list[i];
            list[i] = list[j];
            list[j] = temp;
        }
    }
}
