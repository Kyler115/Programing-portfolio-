﻿using DataStrucures;
using System;
using System.Data;
using System.Dynamic;
using System.Security.Cryptography;
using System.Text;

namespace ProgrammingPortfolio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             * Bloom Filter
             */
            BloomFilter filter = new BloomFilter();
            filter.Add("hello");
            Console.WriteLine(filter.Has("hello"));

            /*
             * Hash test
             */
            HashTable<string> hashTable = new HashTable<string>(10);
            hashTable.Add("hello");
            hashTable.Add("OMG");
            hashTable.Add("stop bruh");
            hashTable.Add("why for why ");
            hashTable.Add("pain");
            Console.WriteLine(hashTable.Has("hello"));
            Console.WriteLine(hashTable.Remove("hello"));
            Console.WriteLine(hashTable.Has("hello"));
            Console.WriteLine(hashTable.ToString());

            /*
             * Priority queue test cases
             */
            PriorityQueue priorityQueue = new PriorityQueue();
            priorityQueue.Add(10);
            priorityQueue.Add(20);
            priorityQueue.Add(15);
            priorityQueue.Add(19);
            priorityQueue.Add(30);
            priorityQueue.Remove(20);
            Console.WriteLine(priorityQueue.Next());
            Console.WriteLine(priorityQueue.UpdatePriority(19, 50));
            priorityQueue.Add(1);

            /*
             * trie test cases
             */
            Utils utils = new Utils();
            Trie trie = new Trie();
            foreach (string word in utils.PasswordWordlist())
            {
                trie.Add(word);
            }
            Console.WriteLine("See if password is common, returns true or false:");
            string userInput = Console.ReadLine();
            Console.WriteLine(trie.has(userInput));
            Console.WriteLine(trie.Remove(""));//put what you want to remove

            /**
             * Binary search tree test case
             */
            BinarySearchTree searchTree = new BinarySearchTree();
            searchTree.Add(4);
            searchTree.Add(2);
            searchTree.Add(1);
            searchTree.Add(3);
            searchTree.Add(6);
            searchTree.Add(7);
            searchTree.Add(8);
            searchTree.Add(9);
            Console.WriteLine(searchTree.Has(3));
            searchTree.ToStringTree();
            Console.WriteLine(searchTree.Remove(3));
            Console.WriteLine(searchTree.Has(3));
            searchTree.ToStringTree();

            /*
             * Quicksort test cases
             */
            int[] array = new int[5];
            array[0] = 3;
            array[1] = 8;
            array[2] = 1;
            array[3] = 2;
            array[4] = 9;
            QuickSort sort = new QuickSort();
            Console.WriteLine(string.Join("|", array));
            sort.quickSort(array);
            Console.WriteLine(string.Join("|", array));

            /*
             * Test cases que
             */
            Queue<string> que = new Queue<string>();
            que.Enqueue("A");
            que.Enqueue("B");
            que.Enqueue("C");
            Console.WriteLine(que.peek());
            que.Dequeue();
            Console.WriteLine(que.peek());
            que.Dequeue();
            Console.WriteLine(que.peek());
            que.Dequeue();

            /*
             * Test cases for dynamic array
             */
            DynamicArray<string> dyno = new DynamicArray<string>();
            dyno.Add("a", 0);
            dyno.Add("b", 1);
            dyno.Add("c", 2);
            dyno.Add("d", 3);
            Console.WriteLine(dyno.Get(0));
            Console.WriteLine(dyno.Get(1));
            Console.WriteLine(dyno.Get(2));
            Console.WriteLine(dyno.Get(3));
            dyno.Remove(1);
            Console.WriteLine(dyno.Get(0));
            Console.WriteLine(dyno.Get(1));
            Console.WriteLine(dyno.Get(2));

            /*
             * Stack test cases
             */
            Stack<string> stack = new Stack<string>();
            stack.Push("a");
            stack.Push("b");
            stack.Push("c");
            stack.Push("d");
            stack.Push("e");
            Console.WriteLine(stack.Peek());
            Console.WriteLine(stack.Pop());
            Console.WriteLine(stack.Peek());
            Console.WriteLine(stack.Pop());
            Console.WriteLine(stack.Peek());

            /*
             * Test Cases for linked list
             */
            LinkedList<string> list = new LinkedList<string>();
            list.AddAt("a", 0);
            list.AddAt("b", 1);
            list.AddAt("c", 2);
            list.AddAt("d", 3);
            list.AddAt("e", 4);
            list.AddAt("f", 5);
            Console.WriteLine(list.Get(0));
            Console.WriteLine(list.Get(1));
            Console.WriteLine(list.Get(2));
            Console.WriteLine(list.Get(3));
            Console.WriteLine(list.Get(4));
            Console.WriteLine(list.Get(5));
            Console.WriteLine(list.RemoveAt(1));
            Console.WriteLine(list.Get(0));
            Console.WriteLine(list.Get(1));
            Console.WriteLine(list.Get(2));
            Console.WriteLine(list.Get(3));
            Console.WriteLine(list.Get(4));
            list.AddAt("wow", 1);
            Console.WriteLine(list.Get(1));
            Console.WriteLine(list.Get(2));
            Console.WriteLine(list.Get(3));
            Console.WriteLine(list.Get(4));

            /*
             * Test Case for slow sort
             */
            int[] test = new int[] { 100, 1, 4, 7, 2, 4, 9, 27, 12 };
            string result = string.Join(" ", test);
            Console.WriteLine(result);
            SlowSort slowSort = new SlowSort();
            slowSort.Sort(test);
            string result2 = string.Join(" ", test);
            Console.WriteLine(result2);
        }
    }
}