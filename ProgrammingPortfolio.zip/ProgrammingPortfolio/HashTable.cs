﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    public class HashTable<LType>
    {
        LNode<LType?>[] buckets; 
        LType? value;
        int key;
        int modValue;
        public HashTable(int numBins)
        {
            buckets = new LNode<LType>[numBins];
            modValue = numBins;
            //mod is the numBins
        }
        public HashTable()
        {
            buckets = new LNode<LType>[100];
            modValue = 100;
        }
        public void Add(LType item)
        {
            this.value = item;
            this.key = Math.Abs(item.GetHashCode()) % modValue;
            LNode<LType> node = new LNode<LType>(item);

            if (buckets[key] != null)
                buckets[key].setNext(node);
            else
                buckets[key] = node;
        }   
        public LType? Remove(LType item)
        {
            for (int i = 0; i <= buckets.Length-1;i++)
            {
                if (buckets[i] == null)
                {
                    break;
                }
                else if (buckets[i].getData().Equals(item))
                {
                    LType type = buckets[i].Data;
                    buckets[i] = null;
                    return item;
                }

            }
            return default(LType);
        }

        public Boolean Has(LType value)
        {
            for (int i = 0; i <= buckets.Length - 1; i++)
            {
                if (buckets[i] == null)
                {
                    break;
                }
                else if (buckets[i].getData().Equals(value))
                {
                    return true;
                }
            }
            return false;
        }



    }
}
