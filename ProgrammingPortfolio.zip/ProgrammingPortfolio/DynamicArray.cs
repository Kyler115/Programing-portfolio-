﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    internal class DynamicArray<LType>
    {
        int length = 2;//initializes int length of two, to be used in size up and potentially other methods.
        int numItems = 0;//number of items inside the array
        LType[] array = new LType[2];//creates array of type L and length 2. 

        /**
         * SizeUp takes the length seen above, an multiplies it by two. It then creates an array called
         * temp with size of length. The original array is then coppied into temp, and that array is deleted
         * and a new one with size length is created in its place. Temp is then coppied into the original array.
         * 
         * Length scales by multiplication of 2.
         */
        private void SizeUp()
        {
            length = length * 2;
            LType[] temp = new LType[length];
            Array.Copy(array, 0, temp, 0, numItems);
            array = new LType[length];
            Array.Copy(temp, 0, array, 0, numItems);
        }

        /**
         * Takes a given int pos and shifts the elements above that position down, effectively keeping the 
         * array compact. Is called by Remove.
         */
        private void ShiftUp(int pos)
        {
            for (int i = pos; i < array.Length - 1; i++)
            {
                array[i] = array[i + 1];
                //Console.WriteLine(array[i]);
            }
        }

        /**
         * Shifts elements down. Makes a new temp array and copies original array into temp, then updates the array
         * at pos t, which is occupied. It then triggers a for loop in which i is the pos+1, and while its less
         * than the index, length, it copies over elements correctly.
         */
        private void ShiftDown(LType t, int pos)
        {
            LType[] temp = new LType[length];
            Array.Copy(array,temp,numItems);
            array[pos] = t;
            for (int i = pos; i < array.Length-1; i++)
            {
                array[i+1] = temp[i];
                //Console.WriteLine(array[i]);
            }
        }

        /**
         * adds values to the array. If the array length is more than one away from the begining or end,
         * an exception is thrown. If the arraylength - pos is zero, then the method calls size up to create
         * a new array with a greater size, and the values are coppied. If an item exists where inserition is 
         * attempted then shift down is called.
         * @see shift down for more info
         */
        public void Add(LType t, int pos)
        {
            if (array.Length + 1 < pos || 0 > pos)
            {
                throw new IndexOutOfRangeException();
            }
            else if (array.Length - pos == 0)
            {
                SizeUp();
            }
            else if (array[pos] != null)
            {
                if (array.Length == numItems)
                    SizeUp();
                ShiftDown(t, pos);
            }
            array[pos] = t;
            numItems = numItems + 1;
        }

        //calls shift up to shift up the array, using a given pos value. removes the value and returns the new one.
        //@SEE shift up for more info.
        public LType Remove(int pos)
        {
            LType result = array[pos];
            ShiftUp(pos);
            numItems = numItems - 1;
            return result;
        }
        
        //gets array value at given index and throws index out of range if that happens.
        public LType Get(int pos)
        {
            //if (numItems-1<pos)
            //    throw new IndexOutOfRangeException();
            return array[pos];
        }

        //returns numItems, unsure why it does not work correctly.
        public int Size()
        {
            return numItems;
        }
        
        //sets given value into array, and returns OLD value.
        public LType Set(LType val, int pos)
        {
            LType place = array[pos];
            array[pos] = val;
            return place;
        }
        }
    }

