﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    internal class Queue<LType>
    {
        private DynamicArray<LType> array = new DynamicArray<LType>();
        public Queue()
        {
            DynamicArray<LType> array = new DynamicArray<LType>();
        }
        public void Enqueue(LType item)
        {
            array.Add(item,array.Size());
        }
        public LType Dequeue()
        {
            if (array.Size()==0)
            {
                throw new IndexOutOfRangeException();
            } 
            return array.Remove(0);
        }
        public LType peek()
        {
            return array.Get(0);
        }
        public int Size()
        {
            return array.Size();
        }
        
    }
}
