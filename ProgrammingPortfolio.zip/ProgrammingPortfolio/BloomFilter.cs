﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    public class BloomFilter
    {
        int numBins;
        Byte[] array;
        int modValue1;
        int modValue2;
        long first;
        long second;
        long third;
        long fourth;
        public BloomFilter(int numBins) 
        {
            this.numBins = numBins;
            array = new Byte[numBins];
            modValue1 = numBins;
            modValue2 = numBins/2;
        }

        public BloomFilter() 
        {
            this.numBins = 100;
            array = new Byte[100];
            modValue1 = 100/2;
            modValue2 = 100;
        }

        public void Add(string item)
        {
            string nf1 = "";
            string nnef1 = "";
            string f1 = MD5(item);
            string nef1 = "";
            int i = 0;
            int j = 0;
            foreach (char c in f1)
            {
                if (c.Equals('0')||c.Equals('1')||c.Equals('2')||c.Equals('3')||c.Equals('4')||c.Equals('5')||c.Equals('6')||c.Equals('7')||c.Equals('8')||c.Equals('9'))
                {
                     nf1 = nf1+c +"";
                }
            }
            string t3 = sha256(item);
            string nt3 = "";
            string net3 = "";
            string nnet3 = "";
            foreach (char c in t3)
            {
                if (c.Equals('0') || c.Equals('1') || c.Equals('2') || c.Equals('3') || c.Equals('4') || c.Equals('5') || c.Equals('6') || c.Equals('7') || c.Equals('8') || c.Equals('9'))
                {
                    nt3 = nt3 + c + "";
                }
            }
            while (i < nf1.Length/2)
            {
                nef1 = nef1+""+nf1[i];//first half of MD5
                i++;//increments for other half
            }
            while (i < nf1.Length)
            {
                nnef1 = nnef1 + nf1[i];//second half
                i++;//increment
            }
            while (j < nt3.Length/8)
            {
                net3 = net3 + "" + nt3[j];
                j++;
                
            }
            while (j < nt3.Length/4)
            {
                nnet3 = nnet3 + nt3[j];
                j++;
            }
            first = long.Parse(nef1) % modValue1;
            second = long.Parse(nnef1) % modValue2;
            third = long.Parse(net3) % modValue1;
            fourth = long.Parse(nnet3) % modValue2;
            array[first] = 1;
            array[second] = 1;
            array[third] = 1;
            array[fourth] = 1;
        }

        /*
         * Implementation based on Ramon Smit's implementation on Stack OverFlow.
         * link:
         * https://stackoverflow.com/questions/11454004/calculate-a-md5-hash-from-a-string
         * Encrypts a string using MD5 algorithm
         */
        public string MD5(string input)
        {
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputB = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashB = md5.ComputeHash(inputB);
                return Convert.ToHexString(hashB);
            }
        }

        /*
         * Implementation from Nico Dumdum's Answer on Stack OverFlow.
         * https://stackoverflow.com/questions/12416249/hashing-a-string-with-sha256
         * encrypts a string using SHA246 algorithm
         */
        public string sha256(string randomString)
        {
            var crypt = new System.Security.Cryptography.SHA256Managed();
            var hash = new System.Text.StringBuilder();
            byte[] crypto = crypt.ComputeHash(Encoding.UTF8.GetBytes(randomString));
            foreach (byte theByte in crypto)
            {
                hash.Append(theByte.ToString("x2"));
            }
            return hash.ToString();
        }

        public Boolean Has(String hasItem)
        {
            string nf1 = "";
            string nnef1 = "";
            string f1 = MD5(hasItem);
            string nef1 = "";
            int i = 0;
            int j = 0;
            foreach (char c in f1)
            {
                if (c.Equals('0') || c.Equals('1') || c.Equals('2') || c.Equals('3') || c.Equals('4') || c.Equals('5') || c.Equals('6') || c.Equals('7') || c.Equals('8') || c.Equals('9'))
                {
                    nf1 = nf1 + c + "";
                }
            }
            string t3 = sha256(hasItem);
            string nt3 = "";
            string net3 = "";
            string nnet3 = "";
            foreach (char c in t3)
            {
                if (c.Equals('0') || c.Equals('1') || c.Equals('2') || c.Equals('3') || c.Equals('4') || c.Equals('5') || c.Equals('6') || c.Equals('7') || c.Equals('8') || c.Equals('9'))
                {
                    nt3 = nt3 + c + "";
                }
            }
            while (i < nf1.Length / 2)
            {
                nef1 = nef1 + "" + nf1[i];//first half of MD5
                i++;//increments for other half
            }
            while (i < nf1.Length)
            {
                nnef1 = nnef1 + nf1[i];//second half
                i++;//increment
            }
            while (j < nt3.Length / 8)
            {
                net3 = net3 + "" + nt3[j];
                j++;

            }
            while (j < nt3.Length / 4)
            {
                nnet3 = nnet3 + nt3[j];
                j++;
            }
            first = long.Parse(nef1) % modValue1;
            second = long.Parse(nnef1) % modValue2;
            third = long.Parse(net3) % modValue1;
            fourth = long.Parse(nnet3) % modValue2;

            if (array[first] == 1 && array[second]==1 && array[third]==1 && array[fourth]==1)
                return true;
            else
                return false;
        }
    }
}
