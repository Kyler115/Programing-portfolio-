﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    public class PriorityQueue
    {
        MaxHeap heap = new MaxHeap();
        public void Add(int item)
        {
            heap.Add(item);
        }

        public int Remove(int item)
        { 
            return heap.Remove(item);
        }
        public int Next()
        {
            return heap.PrioRemove(0);
        }

        public int UpdatePriority(int val, int newPrio)
        {
            int i = 0;
            while (heap.Get(i)!= val)
                i++;
            heap.Set(i, newPrio);
            return heap.Get(i);
        }


    }
}
