﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingPortfolio
{
    internal class TNode
    {
        public TNode[]? child = new TNode[49];
        public char? data;
        //everything was nullable
        public int count;
        public bool isEndOfWord;
        public TNode()
        {
            this.count = 0;
            this.isEndOfWord = false;
        }

        public void SetData(char data)
        {
            this.data = data;
        }

        public void AddChild(TNode node, int index)
        {
            child[index] = node;
        }
    }
}
