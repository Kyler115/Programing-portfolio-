﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks.Dataflow;

namespace ProgrammingPortfolio
{
    internal class BNode
    {
        private int? data;
        private BNode? parent;
        private BNode? lChild;
        private BNode? rChild;
        public BNode(int? data)
        {
            this.data = data;
            this.parent = null;
            this.lChild = null;
            this.rChild = null;
        }
        public void SetParent(BNode parent)
        {
            this.parent = parent;
        }
        public void SetLChild(BNode lChild)
        {
            this.lChild = lChild;
        }
        public void SetRChild (BNode rChild)
        {
            this.rChild = rChild;
        }
        public void SetData(int? data) 
        {
            this.data = data;
        }
        public int GetData()
        {
            if (data == null)
                throw new NullReferenceException();
            return (int)data;
        }

        public BNode? GetRChild()
        {
            return rChild;
        }
        public BNode? GetLChild()
        {
            return lChild;
        }

        public BNode? GetParent() 
        {
            return parent;
        }



    }
}
