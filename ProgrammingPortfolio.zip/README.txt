Kyler VanCamp
898605918

Dynamic Array: No known issues.
issue fixed mentioned. 

Singly Linked List: No Known Issues.

Queue: No known issues.

Stack: No known issues.

Slow Sort: No Known issues.
fixed issue where sort wasnt correct, made adjustment to line of code.

Fast Sort: No Known Issues.

Binary Search Tree: no known issues, use the tostring method for help, implementation works great and is beautiful.
Just added the has method after forgetting to do it.

Tries: Fully functional, no known issues. Tested using the passwords in password util, @see trie tests.

HashTable: Fully Functional, no known issues.

Priority Queue: Fully functional, no known issues. 
!!! NOTE 
PRIORITY UPDATE DOESNT WORK IF THE VALUE ISNT INSIDE THE QUEUE

Bloom Filter: Indexing is based of all the ints in sha256 divided first by 4 and then 8. Works the same way a bloom filter would, just odd methods. also uses found implementation, which prof donze said was okay. it is referenced. 
If any questions, please email me at kvanca1@lsu.edu.




